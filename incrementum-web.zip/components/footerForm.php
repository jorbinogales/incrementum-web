
<?php function footerForm($inputs, $id){ ?>

<section id="form">
        <div class="container">
            <div class="container-fluid">
                <h3>CONTÁCTANOS</h3>
                <form id="formContact<?php echo $id ?>" 
                      method="post"
                      onsubmit="sendEmail(event, <?php echo $id ?>)">
                    <div class="row">
                        <?php foreach($inputs as $input){ ?>
                            <div class="col-12 col-md-4 col">
                                <label class="form" for="<?php echo $input['id'] ?>">
                                
                                    <input type="<?php echo $input['type'] ?>"
                                           placeholder="<?php echo $input['placeholder']?>"  
                                           id="<?php echo $input['id'] ?>"
                                           name="<?php echo $input['id'] ?>"
                                           <?php echo $input['required'] ?>>
                                </label>
                            </div>
                        <?php } ?>
                        <div class="col col-12 col-md-8">
                            <label class="form" for="textForm">
                                <textarea id="textForm" placeholder="CONSULTA" name="message" required></textarea>
                            </label>
                        </div>
                        <div class="col col-12 col-md-4">
                            <input  type="submit" 
                                    class="btn btn-yellow" 
                                    value="ENVIAR">
                        </div>
                    </div>
                </form>
            </div>
        </div>
</section>

<!-- Modal -->
<button
    id="btnSuccess"
    data-toggle="modal" 
    data-target="#successEmail"
    style="display:none;">
</button>

<div class="modal fade" 
     id="successEmail"
     tabindex="-1" 
     role="dialog" 
     aria-labelledby="successEmail" 
     aria-hidden="true">
    <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <h4>Email enviado correctamente</h4>
                    <img src="dist/img/isoTipoColor.png" style="width:100%">
                    <p>Su correo electronico ha sido enviado exitosamente, pronto un miembro del equipo se comunicara contigo</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Ok</button>
                </div>
            </div>
    </div>
</div>

<?php } ?>