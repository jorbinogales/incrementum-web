<?php
    $navs = array (
        0 => array(
            'text' => 'INICIO',
            'page' => 'home'
        ),
        1 => array(
            'text' => 'NOSOTROS',
            'page' => 'about'
        ),
        2 => array(
            'text' => 'SERVICIOS',
            'page' => 'service'
        ),
        3 => array(
            'text' => 'BLOG',
            'page' => 'https://blog.incrementum.pe'
        ),   
        4 => array(
            'text' => 'PREGUNTAS FRECUENTES',
            'page' => 'faq'
        ),
        5 => array(
            'text' => ' CONTÁCTANOS',
            'page' => 'contact'
        )
    );

?>