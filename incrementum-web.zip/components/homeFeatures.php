<?php   
        $features = array(
            0 => array (
                'title' => 'SOLUCIONES INNOVADORAS',
                'description' => 'Nuestra metodología está enfocada en crear soluciones alternativas a la banca
                                    tradicional, centrándonos en las necesidades específicas de cada cliente con
                                    productos y servicios a su medida'
            ),
            1 => array ( 
                'title' => 'RAPIDEZ EN LOS PROCESOS',
                'description' => ' Nos preparamos para atender de manera personalizada a un grupo reducido
                                    de clientes, con los que garantizamos excelentes tiempos de atención y
                                    dedicación por parte de nuestros asesores'
            ),
            2 => array ( 
                'title' => 'EXPERIENCIA COMPROBADA',
                'description' => 'Nuestros socios y aliados cuentan con amplia experiencia profesional en
                                  en banca, mercado de capitales y finanzas'
            ),
            3 => array ( 
                'title' => 'PRINCIPIOS ÉTICOS',
                'description' => 'Actuamos con fidelidad a nuestros principios, respetando a los accionistas,
                                  clientes y entes regulares'
            )
        );
?>
