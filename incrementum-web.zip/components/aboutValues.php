<?php   
        $values = array(
            0 => array(
                'title' => 'HONESTIDAD',
                'description' => 'Garantizamos en nuestras operaciones transparencia, eficiencia y eficacia en todos nuestros procesos.',
            ),
            1 => array(
                'title' => 'FLEXIBILIDAD',
                'description' => 'En medio de una economía dinámica, cambiante y competitiva, nos adaptarnos a los requisitos y la las necesidades de nuestros grupos de interés.',
            ),
            2 => array(
                'title' => 'INTEGRIDAD',
                'description' => 'Actuamos con fidelidad a nuestros principios, respetando a los accionistas, clientes y entes reguladores.',
            ),
            3 => array(
                'title' => 'ENFOQUE AL CLIENTE',
                'description' => 'Satisfacemos las necesidades de nuestros clientes a través de una asesoría profesional, personalizada, responsable y dedicada.',
            ),
            4 => array(
                'title' => 'COMPROMISO',
                'description' => 'Nuestra filosofía está orientada al cumplimiento de los objetivos y metas, desarrollando y fortaleciendo las competencias de nuestros clientes y aliados para que estos alcancen su máximo potencial.',
            ),
        );
?>