<?php 
    require 'footer.php';
    require 'header.php';
    require 'navbar.php';
    require 'headerNavbar.php';
    require 'components/homeForm.php';
?>